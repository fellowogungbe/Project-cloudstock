// Configure the API base URL when your backend is deployed.
// Keep this file free of secrets. Browser code is public.
export const config = {
  mode: "demo", // "demo" uses localStorage; "api" uses your backend
  apiBaseUrl: "http://localhost:8000/api",
  lowStockDefault: 5
};
